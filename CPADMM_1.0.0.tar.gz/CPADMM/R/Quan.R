#' @title Quan
#' @description The closed-form solution of quantile loss.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size.
#' @param mu The augmented Lagrange constant.
#' @param ka The constants need to be given in Huber.
#' @param rr The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the loss.
#' @export
Quan=function(tau,n,mu,ka=0,rr){
  xu=rep(0,length(rr))
  for(i in 1:length(rr)){
    xu[i]=max(rr[i]-tau/(n*mu),min(0,rr[i]+(1-tau)/(n*mu)))}
  return(xu)
}