#' @title LS
#' @description The closed-form solution of least squares loss.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size.
#' @param mu The augmented Lagrange constant.
#' @param ka The constants need to be given in Huber.
#' @param rr The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the loss.
#' @export
LS=function(tau=0,n,mu,ka=0,rr){
  xu=n*mu*rr/(1+n*mu)
  return(xu)
}
