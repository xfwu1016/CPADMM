#' @title CPADMMF
#' @description The main function for solving various sparse fused regressions.
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation.
#' @param y Response variable
#' @param loss A character string specifying the loss function to use. Available options are least squares loss (LS),  square root loss (SR), Huber loss (Huber) and quantile loss (Quan).
#' @param pen A character string specifying the first penalty to use. Available options are L1(LASSO), SCAD and MCP.
#' @param lambda1 The tuning parameter for the first penalty.
#' @param lambda2 The tuning parameter for the second penalty.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param ka The constants need to be given in Huber loss.
#' @param maxite Maximum number of iterations allowed in the ADMM algorithm at fixed lambda values. If the algorithm does not converge, consider increasing maxite.
#' @param M The number of local machines.
#' @returns \item{beta}{Regression coefficient.}
#' @returns \item{K}{Number of iterations.}
#' @returns \item{time}{Calculation time.}
#' @export
#' @examples
#' #######Example 1(High-dimensional regression)
#' s=1#s=1,2,3,4,5....
#' n=720*10^0#*100
#' p=2560*s
#' index=1:80
#' ind=sample(index,10)
#' beta=rep(0,p)
#' for (i in 1:10) {
#'   beta[((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))]=rep(runif(1,-3,3),(32*s))
#' }
#' 
#' plot(beta)
#' 
#' rho <- 0.5 
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' 
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1) 
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.5#0.5,1.5
#' y <- X %*% beta + delte*error
#' F_matrix<-function(p)
#' {
#'   F=matrix(0,p-1,p)
#'   for(i in 1:(p-1))
#'   {
#'     F[i,i]=1
#'     F[i,i+1]=-1
#'   }
#'   return(F)
#' }
#' F_m=F_matrix(p)
#' #
#' #
#' FTF=function(p){
#'   if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
#'     FTF=diag(2,p)
#'     for (i in 2:p) {
#'       FTF[i-1,i]=-1
#'       FTF[i,i-1]=-1
#'     }
#'     FTF[1,1]=1
#'     FTF[p,p]=1}
#'   return(FTF)
#' }
#' FF=FTF(p)
#' 
#' lambda=0.5*sqrt(log(p)/n)
#' alpha=0.2
#' lambda1 = alpha*lambda
#' lambda2 = 1*(1-alpha)*lambda
#' tau=0.5
#' 
#' maxite = 200
#' ka=IQR(y)/10
#' 
#' M=1
#' fmodel = CPADMMF(X,y,loss="Quan",pen="MCP",lambda1,lambda2,tau,ka,maxite,M) 
#' fmodel$K
#' fmodel$time
#' plot(beta)
#' plot(fmodel$beta)
#' 
#' #######Example 2(Massive data regression)
#' s=0.5
#' n=720*10^3#*100
#' p=2560*s
#' index=1:80
#' ind=sample(index,10)
#' beta=rep(0,p)
#' for (i in 1:10) {
#'   beta[((ind[i]-1)*(32*s)+1):((ind[i]-1)*(32*s)+(32*s))]=rep(runif(1,-3,3),(32*s))
#' }
#' 
#' plot(beta)
#' 
#' rho <- 0.5 
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' 
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1) 
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.5#0.5,1.5
#' y <- X %*% beta + delte*error
#' F_matrix<-function(p)
#' {
#'   F=matrix(0,p-1,p)
#'   for(i in 1:(p-1))
#'   {
#'     F[i,i]=1
#'     F[i,i+1]=-1
#'   }
#'   return(F)
#' }
#' F_m=F_matrix(p)
#' #
#' #
#' FTF=function(p){
#'   if(p==2){FTF=matrix(c(1,-1,-1,1),2,2)}else{
#'     FTF=diag(2,p)
#'     for (i in 2:p) {
#'       FTF[i-1,i]=-1
#'       FTF[i,i-1]=-1
#'     }
#'     FTF[1,1]=1
#'     FTF[p,p]=1}
#'   return(FTF)
#' }
#' FF=FTF(p)
#' 
#' lambda=0.5*sqrt(log(p)/n)
#' alpha=0.2
#' lambda1 = alpha*lambda
#' lambda2 = 1*(1-alpha)*lambda
#' tau=0.5
#' 
#' maxite = 200
#' ka=IQR(y)/10
#' 
#' M=10#M=1,10,100
#' fmodel = CPADMMF(X,y,loss="Quan",pen="MCP",lambda1,lambda2,tau,ka,maxite,M) 
#' fmodel$K
#' fmodel$time
#' plot(beta)
#' plot(fmodel$beta)

CPADMMF = function(X,y,loss,pen,lambda1,lambda2,tau,ka,maxite,M){
  lambda1 = lambda1
  maxite = maxite
  lambda2 = lambda2
  M=M
  pen = pen
  loss = loss
  if(loss=="LS"){L=LS}else if(loss=="SR"){L=SR}else if(loss=="Quan"){
    L=Quan}else{L=Huber}  
  if(pen=="L1"){
    beta_lla = rep(0.001,p)
    lambdav = lambda1
    pena = LASSO;
    CPADMM = Sfl(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav)
    time = 0
    CPADMM$time = CPADMM$time + time
  }else if(pen=="MCP"){
    beta_lla = rep(0.001,p)
    lambdav = lambda1
    pena = MLASSO;
    L1model = Sfl(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav);
    beta_lla =  L1model$beta
    time =  L1model$time 
    lambdav = mcp(a=3,beta_lla)  
    CPADMM = Sfl(loss,pen="MCP",beta_lla=beta_lla,lambdav=lambdav)
    CPADMM$time = CPADMM$time + time
  }else{
    beta_lla = rep(0.001,p)
    lambdav = lambda1
    pena = MLASSO;
    L1model = Sfl(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav);
    beta_lla =  L1model$beta;
    time =  L1model$time;
    lambdav = scad(a=3.7,beta_lla);
    CPADMM = Sfl(loss,pen="SCAD",beta_lla=beta_lla,lambdav=lambdav)
    CPADMM$time = CPADMM$time + time
  }
  return(CPADMM)
  
}
