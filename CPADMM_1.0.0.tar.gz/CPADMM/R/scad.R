#' @title scad
#' @description The function of the first derivative of the scad penalty term in the production LLA algorithm.
#' @param a The constants need to be given in scad. The The value is usually 3.7.
#' @param beta_lla The initial value of the LLA algorithm.
#' @return The first derivative of the scad penalty term.
#' @export
scad <- function(a=3.7,beta_lla){
  Der= rep(0,length(beta_lla))
  for (i in 1:length(beta_lla)) {
    if(abs(beta_lla[i])<=lambda1 ){Der[i] = lambda1}else if(abs(beta_lla[i])> a*lambda1){
      Der[i] = 0}else{Der[i] = (a*lambda1 - abs(beta_lla[i]))/(a-1)}}  
  return(Der)
}