#' @title CPADMME
#' @description  The main function for solving various elastic-net regressions.
#' @param X Matrix of predictors, of dimension (n*p); each row is an observation.
#' @param y Response variable.
#' @param loss A character string specifying the loss function to use. Available options are least squares loss (LS),  square root loss (SR), Huber loss (Huber) and quantile loss (Quan).
#' @param pen A character string specifying the first penalty to use. Available options are L1(LASSO), SCAD and MCP.
#' @param lambda1 The tuning parameter for the first penalty.
#' @param lambda2 The tuning parameter for the second penalty.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param ka The constants need to be given in Huber loss.
#' @param maxite Maximum number of iterations allowed in the ADMM algorithm at fixed lambda values. If the algorithm does not converge, consider increasing maxite.
#' @param M The number of local machines.
#' @returns \item{beta}{Regression coefficient.}
#' @returns \item{K}{Number of iterations.}
#' @returns \item{time}{Calculation time.}
#' @export
#' @examples
#' #######Example 1(High-dimensional regression)
#' s=1# s=1,2,3,4,5,...
#' n=720
#' p=2560*s
#' beta=rep(0,p)
#' for (j in 1:p) {
#'   beta[j] = (-1)^j*exp(-(2*j-1)/20)
#' }
#' rho <- 0.5 
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1) 
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.5#0.5,1.5
#' y <- X %*% beta + delte*error
#' lambda=0.5*sqrt(log(p)/n)
#' maxite=200
#' alpha=0.9
#' lambda1 = alpha*lambda
#' lambda2 = (1-alpha)*lambda
#' tau=0.5
#' ka=IQR(y)/10
#' M=1
#' Enetmodel=CPADMME (X,y,loss="LS",pen="SCAD",lambda1,lambda2,tau,ka,maxite,M)#loss=”LS”,”SR”,”Quan”,”Huber”; #and pen = “L1”,”SCAD”,”MCP” .
#' Enetmodel$K
#' Enetmodel$time
#' plot(beta)
#' beta[1:10]
#' Enetmodel$beta[1:10]
#' plot(Enetmodel$beta)
#' 
#' 
#' #######Example 2(Massive data regression)
#' s=0.5
#' n=72000
#' p=2560*s
#' beta=rep(0,p)
#' for (j in 1:p) {
#'   beta[j] = (-1)^j*exp(-(2*j-1)/20)
#' }
#' rho <- 0.5 
#' R <- matrix(0,p,p)#
#' for(i in 1:p){
#'   for(j in 1:p){
#'     R[i,j] <- rho^abs(i-j)
#'   }
#' }
#' error=rnorm(n,0,1)#rt(n,1.5),rnorm(n,0,1),rcauchy(n,0,1) 
#' X <- matrix(rnorm(n*p),n,p) %*% t(chol(R))#chol
#' X=scale(X,center=FALSE,scale=TRUE)
#' delte=0.5#0.5,1.5
#' y <- X %*% beta + delte*error
#' lambda=0.5*sqrt(log(p)/n)
#' maxite=200
#' alpha=0.9
#' lambda1 = alpha*lambda
#' lambda2 = (1-alpha)*lambda
#' tau=0.5
#' ka=IQR(y)/10
#' M=10#M=1,10,100
#' Enetmodel=CPADMME (X,y,loss="LS",pen="SCAD",lambda1,lambda2,tau,ka,maxite,M)#loss=”LS”,”SR”,”Quan”,”Huber”; #and pen = “L1”,”SCAD”,”MCP” .
#' Enetmodel$K
#' Enetmodel$time
#' plot(beta)
#' beta[1:10]
#' Enetmodel$beta[1:10]
#' plot(Enetmodel$beta)

CPADMME = function(X,y,loss,pen,lambda1,lambda2,tau,ka,maxite,M){
  lambda1 = lambda1
  maxite = maxite
  lambda2 = lambda2
  M=M
  pen = pen
  loss = loss
  if(loss=="LS"){L=LS}else if(loss=="SR"){L=SR}else if(loss=="Quan"){
    L=Quan}else{L=Huber}  
  if(pen=="L1"){
    beta_lla = rep(0,p)
    lambdav = lambda1
    pena = LASSO;
    CPADMM = Enet(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav)
    time = 0
    CPADMM$time = CPADMM$time + time
  }else if(pen=="MCP"){
    beta_lla = rep(0,p)
    lambdav = lambda1
    pena = MLASSO;
    L1model = Enet(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav);
    beta_lla =  L1model$beta
    time =  L1model$time 
    lambdav = mcp(a=3,beta_lla)  
    CPADMM = Enet(loss,pen="MCP",beta_lla=beta_lla,lambdav=lambdav)
    CPADMM$time = CPADMM$time + time
  }else{
    beta_lla = rep(0,p)
    lambdav = lambda1
    pena = MLASSO;
    L1model = Enet(loss,pen="L1",beta_lla=beta_lla,lambdav=lambdav);
    beta_lla =  L1model$beta;
    time =  L1model$time;
    lambdav = scad(a=3.7,beta_lla);
    CPADMM = Enet(loss,pen="SCAD",beta_lla=beta_lla,lambdav=lambdav)
    CPADMM$time = CPADMM$time + time
  }
  return(CPADMM)
  
}
