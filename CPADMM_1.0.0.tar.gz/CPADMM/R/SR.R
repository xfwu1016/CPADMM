#' @title SR
#' @description The closed-form solution of square root loss.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size.
#' @param mu The augmented Lagrange constant.
#' @param ka The constants need to be given in Huber.
#' @param rr The constant vectors in the proximal operators
#' @return The solution for the proximal operators of the loss.
#' @export
SR=function(tau=0,n,mu,ka=0,rr){
  re=rep(0,length(rr))
  re=rr/sqrt(sum(rr^2))*max(0, sqrt(sum(rr^2))-1/(sqrt(2*n)*mu))
  return(re)
}