#' @title Huber
#' @description The closed-form solution of Huber loss.
#' @param tau The quantile level τ. The value must be in (0,1).
#' @param n The sample size.
#' @param mu The augmented Lagrange constant.
#' @param ka The constants need to be given in Huber.
#' @param rr The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the loss.
#' @export
Huber<-function(tau=0,n,mu,ka=1,rr){
  r_k=rep(0, length(rr))
  for (i in 1:length(rr)) {
    if(abs(rr[i]) > ka+1/(n*mu)){r_k[i]=sign(rr[i])*max(abs(rr[i])-
                                                          1/(n*mu),0)}else{
                                                            r_k[i] = (mu*rr[i])/(mu + 1/(n*ka))
                                                          }
  }
  return(r_k)
}
