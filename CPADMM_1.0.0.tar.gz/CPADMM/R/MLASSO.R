#' @title MLASSO
#' @description The closed-form solution of weighted soft threshold operator.
#' @param lambdav The weighted tuning parameter for the first penalty.
#' @param mmu The constant for the proximal operators of the penalty.
#' @param x The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the penalty.
#' @export
MLASSO = function(lambdav,mmu,x){ 
  #plot(beta_lla)
  r<-rep(0,length(x))
  for(i in 1:length(x)){
    r[i]<-sign(x[i])*max(0,abs(x[i])-lambdav[i]/mmu)}
  return(r)
}
