#' @title Enet
#' @description The function for calculating weighted elastic-net regression.
#' @param loss A character string specifying the loss function to use. Available options are least squares loss (LS),  square root loss (SR), Huber loss (Huber) and quantile loss (Quan).
#' @param pen A character string specifying the first penalty to use. Available options are L1(LASSO), SCAD and MCP.
#' @param beta_lla The initial value of the LLA algorithm.
#' @param lambdav The tuning parameter for the first penalty.
#' @returns \item{beta}{Regression coefficient.}
#' @returns \item{K}{Number of iterations.}
#' @returns \item{time}{Calculation time.}
#' @returns \item{err}{Estimation error.}
#' @export
Enet = function(loss,pen,beta_lla,lambdav){
  if(loss=="LS"){L=LS}else if(loss=="SR"){L=SR}else if(loss=="Quan"){
    L=Quan}else{L=Huber}  
  if(pen=="L1"){pena = LASSO}else{pena=MLASSO}
  mu=10^-1#10^-3
  n=nrow(X)
  p=ncol(X)
  ite=maxite
  
  #M <- 1
  #
  begint <- proc.time()
  if(pen == "L1"){
    CbetaM= matrix(0.0,p,1)
    CbetaU= matrix(0.1,p,1)}else{
      CbetaM= matrix(0.0,p,1)
      CbetaU= matrix(0.1,p,1)
      CbetaM = as.matrix(beta_lla,p,1)
      CbetaU = as.matrix(beta_lla,p,1)}
  
  #
  if(pen == "L1"){
    betaM=matrix(0.1,p,M);
    betaU=matrix(0.1,p,M)}else{
      betaM=matrix(0.1,p,M);
      betaU=matrix(0.1,p,M)
      for (m in 1:M) {betaM[,m]=beta_lla}
      betaU = betaM}
  #
  if(pen == "L1"){
    bM=matrix(0.1,p,1)
    bU=matrix(0.1,p,1)}else{
      bM=matrix(0.1,p,1)
      bU=matrix(0.1,p,1)
      bM = as.matrix(beta_lla,p,1)
      bU = bM
    }
  
  #
  rM=matrix(0.01,n/M,M)
  rU=matrix(0.01,n/M,M)
  
  dM=matrix(0.01,n/M,M)
  dU=matrix(0.01,n/M,M)
  #
  eM=matrix(0.0,p,M)
  eU=matrix(0.0,p,M)
  #
  fM=matrix(0.01,p,1)
  fU=matrix(0.01,p,1)
  
  group <- list()
  Inv_array <- array(0, dim=c(p, p, M))
  for (aa in 1:M) {
    group[[aa]] <- (1:n)[(n/M*(aa-1)+1) : (n/M*aa)]
  }
  time_e=rep(0,M)
  for (aa in 1:M) {
    begin <- proc.time()
    Inv_array[,,aa] = X_inv(X[group[[aa]],])
    end <- proc.time()
    time_e[aa]=(end-begin)[3]
  }
  
  #Xinv = X_inv(X)
  #M=1
  #FI = rbind(diag(sqrt(M),p),F)
  #eta=M #pite2(FI,x=rep(1,ncol(FI)),ite=1000)[1]+4
  
  #A=FF+diag(M,p)
  k=0
  
  time_m=matrix(0,M,ite+1)
  repeat{
    bbk = (M*(rowMeans(betaM) - rowMeans(eM)/mu) + (bM + fM/mu))/(M+1)
    if(pen=="L1"){lambdav = lambda1}
    CbetaU = pena(lambdav,mu*(M+1),bbk)
    bb2 = CbetaU - fM/mu
    bU = mu * bb2/(2*lambda2+mu)
    for (m in 1:M) {
      begin <- proc.time()
      bb3 = t(X[group[[m]],])%*%(y[group[[m]]] + dM[,m]/mu - rM[,m]) + (CbetaU + eM[,m]/mu)
      betaU[,m] = Inv_array[,,m]%*%bb3
      bb4 = y[group[[m]]] + dM[,m]/mu - X[group[[m]],]%*%betaU[,m]
      rU[,m]  = L(tau,n,mu,ka,bb4)#
      dU[,m] = dM[,m] - mu*(X[group[[m]],]%*%betaU[,m] + rU[,m] -y[group[[m]]]) 
      eU[,m] = eM[,m] - mu*(betaU[,m] - CbetaU)
      end <- proc.time()
      time_m[m,k+1]=(end-begin)[3]}
    fU = fM - mu*(CbetaU - bU)
    
    Perror= sqrt(sum((betaU-betaM)^2))/max(1,sqrt(sum(betaM^2)))
    if((k>10)&((Perror<10^-3)|(k>ite-1))){break}#*(sqrt(M))
    
    CbetaM = CbetaU
    bM = bU
    betaM = betaU
    rM = rU
    dM = dU
    eM = eU
    fM = fU
    
    k = k+1
  }
  
  endt <- proc.time()
  Tol=endt-begint
  maxtime=0
  
  for (j in 1:ite) {maxtime = maxtime+max(time_m[,j])
  }
  result=list(beta=bU,K=k,time = Tol[3] - sum(time_m)+ maxtime - sum(time_e)+ max(time_e),
              err=Perror)
  return(result)
}
