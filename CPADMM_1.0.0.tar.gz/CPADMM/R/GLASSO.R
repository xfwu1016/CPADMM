#' @title GLASSO
#' @description The closed-form solution of group soft threshold operator.
#' @param lambda2 The tuning parameter for the second penalty.
#' @param mu The constant for the proximal operators of the penalty.
#' @param bbb The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the penalty.
#' @export
GLASSO=function(lambda2,mu,bbb){
  re=rep(0,length(bbb))
  re=bbb/sqrt(sum(bbb^2))*max(0, sqrt(sum(bbb^2))-lambda2/mu)
  return(re)
}
