#' @title LASSO
#' @description The closed-form solution of  soft threshold operator.
#' @param lambda The tuning parameter for the second penalty.
#' @param mmu The constant for the proximal operators of the penalty.
#' @param x The constant vectors in the proximal operators.
#' @return The solution for the proximal operators of the penalty.
#' @export
LASSO<-function(lambda,mmu,x)
{ r<-rep(0,length(x))
for(i in 1:length(x)){
  r[i]<-sign(x[i])*max(0,abs(x[i])-lambda/mmu)}
return(r)
}
